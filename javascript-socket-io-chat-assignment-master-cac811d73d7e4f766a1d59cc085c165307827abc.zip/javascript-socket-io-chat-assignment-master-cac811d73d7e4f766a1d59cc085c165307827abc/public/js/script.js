function sendMessage(event, socket) {
	event.preventDefault();

	const username = document.getElementById('username').value;
	const channel = document.getElementById('channel').value;
	const message = document.getElementById('message').value;

	let chatElement = document.getElementById('chatContainer');
	const messageElement = document.createElement('div');
	messageElement.innerHTML = `<div class="col-12">
	<div class="card sent-message">
		<div class="card-body">
			<p class="card-text">Me : ${message}</p>
		</div>
	</div>
</div>`;
	messageElement.className = 'col-12 message align-self-end';
	chatElement.insertBefore(messageElement, chatElement.firstChild);

	if (!document.getElementById('channelsList').innerHTML.includes(channel)) {
		socket.emit('joinChannel', channel);
	}

	socket.emit('message', { username, channel, message });
}

function joinChannel(event, socket) {
	event.preventDefault();
	let newCH = document.getElementById('newchannel').value;
	document.getElementById('newchannel').value = '';

	if (newCH !== 'undefined' && newCH !== '') {
		socket.emit('joinChannel', { channel: newCH });
	}
}

function leaveChannel(event, socket) {
	let leaveCH = document.getElementById('newchannel').value;
	document.getElementById('newchannel').value = '';

	if (leaveCH !== 'undefined' && leaveCH !== '') {
		socket.emit('leaveChannel', { channel: leaveCH });
	}
}

function onWelcomeMessageReceived(message) {
	let chatElement = document.getElementById('chatContainer');
	let messageElement = document.createElement('div');
	messageElement.setAttribute('class', 'col-12');
	messageElement.innerHTML = `<div class="card received-message">
				<div class="card-body">
					<p class="card-text">System : ${message}</p>
				</div>
			</div>`;
	chatElement.appendChild(messageElement);
}

function onNewMessageReceived(message) {
	let chatElement = document.getElementById('chatContainer');
	const messageElement = document.createElement('div');
	messageElement.innerHTML = `<div class="col-12">
		<div class="card received-message">
			<div class="card-body">
				<p class="card-text">${message.username} : ${message.message}</p>
			</div>
		</div>
	</div>`;
	chatElement.insertBefore(messageElement, chatElement.firstChild);
}

function onAddedToNewChannelReceived(objCh) {
	document.getElementById('alertContainer').innerHTML =
		`<div class="alert alert-success alert-dismissible fade show" role="alert">
		You are added to <strong>${objCh.channel}</strong> successfully!
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>`;

	let channelsList = document.getElementById('channelsList');
	if (!channelsList.innerHTML.includes(objCh.channel)) {
		let optionElement = document.createElement('option');
		optionElement.innerHTML = objCh.channel;
		channelsList.appendChild(optionElement);
	}
}

function onRemovedFromChannelReceived(objCh) {
	document.getElementById('alertContainer').innerHTML =
		'<div class="alert alert-success alert-dismissible fade show" role="alert">'
		+ `You are removed from <strong>${objCh.channel}</strong> successfully!`
		+ '<button type="button" class="close" data-dismiss="alert" aria-label="Close">'
		+ '<span aria-hidden="true">&times;</span>'
		+ '</button></div>';

	let existList = document.getElementById('channelsList');
	let optionsList = existList.getElementsByTagName('option');

	for (let i = 0; i < optionsList.length; i = i + 1) {
		if (optionsList[i].value === objCh.channel) {
			existList.removeChild(optionsList[i]);
		}
	}
}

module.exports = {
	sendMessage,
	joinChannel,
	leaveChannel,
	onWelcomeMessageReceived,
	onNewMessageReceived,
	onAddedToNewChannelReceived,
	onRemovedFromChannelReceived
};

// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution
