function bootstrapSocketServer(io) {
	io.on('connection', (socket) => {
		socket.on('register', (objUser) => {
			socket.emit('welcomeMessage', `Welcome ${objUser.username} !!`);
			if (Array.isArray(objUser.channels)) {
				objUser.channels.forEach(channel => {
					socket.join(channel);
					socket.emit('addedToChannel', { channel: channel });
				}
				);
			}
			else {
				socket.join(objUser.channels);
				socket.emit('addedToChannel', { channel: objUser.channels });
			}

			socket.on('joinChannel', (objChannel) => {
				socket.join(objChannel.channel);
				socket.emit('addedToChannel', { channel: objChannel.channel });
			});

			socket.on('leaveChannel', (objChannel) => {
				socket.leave(objChannel.channel);
				socket.emit('removedFromChannel', { channel: objChannel.channel });
			});

			socket.on('message', (objMsg) => {
				socket.to(objMsg.channel).emit('newMessage',
					{ username: objMsg.username, channel: objMsg.channel, message: objMsg.message });
			});
		});
	});
}

module.exports = bootstrapSocketServer;
