## Notes Application
This is a simple node.js application with MongoDB access, can be used to implementation for CRUD operations with MongoDB

This expects the environment variable MONGO_URL, which you can set using below command 

On Linux platform
```
export MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - $MONGO_URL
```

On Windows platform
```
SET MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - %MONGO_URL%
```
### Application Details:
- User can register and login & logout
- User can perform CRUD operations on notes, notification and reminder feature is included
- User can shared note with other users
- User can add notes to group or mark it as favourites

#### Using docker-compose
- Build and start
```docker-compose up --build ```
- Stop
```docker-compose down ```
- Connect Mongo DB
```docker exec -it notes_app_db mongo ```

#### API service documentations
- [API Service](./appServices/README.md)
- [Notifications Service](./notificationService/README.md)