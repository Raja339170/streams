## Notes Application (Notification Service)
This is a simple node.js application with MongoDB access, can be used to implementation for CRUD operations with MongoDB

This expects the environment variable MONGO_URL, which you can set using below command 

On Linux platform
```
export MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - $MONGO_URL
```

On Windows platform
```
SET MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - %MONGO_URL%
```

### Application Details:
- User can get, add, update, delete reminders
- User can notify other users

### API Specification:

- Notify a user: 
POST http://localhost:3003/api/v1/notifications/
Body: ```{ userName: "<userName>", note: { "title": <title>, "text": <text> }```

- Get all reminders for a user: 
GET http://localhost:3003/api/v1/notifications/reminders
Headers: ```Authorization Bearer <jwt-token>```

- Add a reminder for a user: 
POST http://localhost:3003/api/v1/notifications/reminders
Body: ```{ userName: "<userName>", remindAt: "<time>", note: { "title": <title>, "text": <text> } }```
Headers: ```Authorization Bearer <jwt-token>```

- Update/Snooze a reminder for a user: 
PUT http://localhost:3003/api/v1/notifications/reminders/:reminderId
Body: ```{ userName: "<userName>", remindAt: "<time>", note: { "title": <title>, "text": <text> } }```
Headers: ```Authorization Bearer <jwt-token>```

- Delete/Dismiss reminder for a user: 
DELETE http://localhost:3003/api/v1/notifications/reminders/:reminderId
Headers: ```Authorization Bearer <jwt-token>```

### How to run this project

1. Install dependencies

```
npm install
```

or

```
yarn
```

2. Run application from terminal

```
npm start
```

3. Run test cases from terminal

```
npm run test
```

4. Run lint checks from terminal

```
npm run lint
```
