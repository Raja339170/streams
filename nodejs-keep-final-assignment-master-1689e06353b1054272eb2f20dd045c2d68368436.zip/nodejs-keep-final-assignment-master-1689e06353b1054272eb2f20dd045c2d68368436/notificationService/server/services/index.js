const authServices = require('./auth.services');

module.exports = {
    authServices
}