const log = require('./logging');
const appConfig = require('./config').appConfig;
const notificationsDao = require('./api/v1/notifications/notifications.dao');
const socket = require('./socket');
const async = require('async');

const registerWorker = () => {
  async.forever(
    (next) => {
      doWork();
      //Repeat after the delay
      setTimeout(() => { /* eslint-disable-line no-undef */
        next();
      }, appConfig.sleepDuration)
    },
    (err) => {
      log.error('Error occurred while polling database');
      log.error(err);
    }
  )
}

const doWork = () => {
  log.info('starting process');
  notificationsDao.getNotificationsToProcess((err, notifications) => {
    if(err) {
      log.error('Error occurred while fetching notifications');
      log.error(err);
    }
    log.info('notifications fetched from db');
    if (notifications && notifications.length > 0) {
      log.info('notifications found');
      notifications.map(n => {
        if (IsLessThanCurrentTime(n.remindAt) && !n.isSent) {
          const res = socket.notify(n);
          if(res) {
            notificationsDao.markNotificationSent(n._id)
            .then(res => log.debug(res))
            .catch(err => log.error(err));
          }
        }
      });
    }
  });
  log.info('process completed, waiting for next round ...');
}

const IsLessThanCurrentTime = (remindAt) => {
  let curDate = new Date();
  let remindDate =   new Date(remindAt);
  let dateDiffMins = parseInt((remindDate - curDate)/ (1000*60));
  log.debug('checking datetime: now: ' + curDate.toISOString() + 
    ' and reminder: ' + remindDate.toISOString() + ' and Date diff: '+ dateDiffMins);
  return curDate >= remindDate || dateDiffMins == 15;
}

module.exports = {
  registerWorker
};