const notesDao = require('./notes.dao');
const usersServices = require('../users/users.services');
const notificationService = require('../../../services').notificationServices;
const log = require('../../../logging');

const getNotesByUserId = (userId) => {
  return notesDao.getAllNotes(userId)
}

const updateNote = (userId, noteId, note, token) => {    
  return new Promise((resolve, reject) => {
    notesDao.isUserAllowed(userId, noteId)
    .then(result =>  notesDao.updateNote(noteId, note))
    .then((result) => {                        
      let notes = []; 
      notes.push(result.note);      
      log.debug('On update adding a reminder for user: ' + userId + ' note : ' + JSON.stringify(notes));                
      result.note.shareusers.forEach(shareuser => {
        notificationService.notifyUser(shareuser.userName, notes, token); 
      }); 
      resolve(result);                     
    })    
    .catch(err => reject(err));  
  });
};

const addNote = (userId, note) => {
  return notesDao.createNote(userId, note);
}

const getNotesAsStream = (res, userId) => {
  notesDao.readNotesAsStream(userId)
    .then((result) => {
      res.set('Content-Type', 'application/json');
      result.pipe(res);
    })
    .catch((error) => {
      res.status(error.status).json(error);
    });
}

const uploadNotes = (userId, notes) => {
  return notesDao.bulkInsert(userId, notes);
};

const shareNotes = (shareuser, notes, token) => {
  return new Promise((resolve, reject) => {
    usersServices.getByUserName(shareuser.userName)
    .then((result) => {    
        shareuser.userId = result.user.userId;      
        notesDao.addShareuser(shareuser, notes)
        .then((result) => {
          notificationService.notifyUser(shareuser.userName, notes, token);
          resolve(result);
        })
        .catch((error) => reject(error));
    });
  });
};

const deleteNote = (userId, noteId) => {
  return new Promise((resolve, reject) => {
    notesDao.isUserAllowed(userId, noteId)
    .then(() => resolve(notesDao.deleteNote(noteId)))
    .catch(err => reject(err));
  });
};

const deleteMultipleNote = (userId, noteIds) => {
  return new Promise((resolve, reject) => {
    notesDao.isUserAllowed(userId, noteIds[0])
    .then(() => resolve(notesDao.deleteNotes(noteIds)))
    .catch(err => reject(err));
  });
};

const addToFavourites = (noteIds) => {
  return notesDao.addToFavourites(noteIds);
};

const addToGroup = (groupName, noteIds) => {
  return notesDao.addToGroup(groupName, noteIds);
};

module.exports = {
  getNotesByUserId,
  updateNote,
  addNote,
  getNotesAsStream,
  uploadNotes,
  shareNotes,
  deleteNote,
  deleteMultipleNote,
  addToFavourites,
  addToGroup
}