
const notificationServices = require('./notification.services');
const authServices = require('./auth.services');

module.exports = {    
    notificationServices,
    authServices
}