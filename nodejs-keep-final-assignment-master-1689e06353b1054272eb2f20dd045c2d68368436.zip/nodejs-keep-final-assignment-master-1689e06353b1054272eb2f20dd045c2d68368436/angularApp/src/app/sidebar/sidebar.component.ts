import { Component, OnInit } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  groups = Array<string>();  

  constructor(private notesService: NotesService,
    private routerService: RouterService) {
    this.notesService.getNotes().subscribe(notes => {
      this.groups = notes.map(n => n.groupName)
        .filter((value, index, self) => {
          return self.indexOf(value) === index && value;
        });
    });    
  }

  ngOnInit() {
  }

  showAllNotes() {
    this.notesService.showAllNotes();    
  }

  showNotesInGroup(group) {
    this.notesService.showNotesInGroup(group);    
  }

  showFavourites() {
    this.notesService.showFavourites();    
  }

  showReminders() {
    this.routerService.routeToReminderListView();
  }
}
