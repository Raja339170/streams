// write your db connection code here
let mongoose = require('mongoose');
const { dbConfig }  = require('../config').appConfig;

// create mongo connection
function createMongoConnection() {
  mongoose.connect(dbConfig.mongoUrl);
}

module.exports = {
  createMongoConnection
}