const router = require('express').Router();

//write your routes here
router.use('/notes', require('./notes'));
router.use('/users', require('./user'));

router.use((req, res) => {
    return res.status(404).send('Not Found');
})

// exporting router to handle request
module.exports = router;
