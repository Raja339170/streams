const userService =  require('./user.services')

// Handler to register new user
const addUser = (userInfo) => {
	return userService.addUser(userInfo);
}

// Handler to verify user
const verifyUser = (userInfo) => {
	return userService.verifyUser(userInfo);
}

module.exports = {
  addUser,
  verifyUser
}
