let userModel = require('./user.entity');
let bcrypt = require('bcryptjs');
let uuid = require('uuid/v4');
let auth = require('../auth');

const { tokenConfig } = require('../../../config').appConfig;

// Handler to check whether the user is exists
const findUser = (userInfo) => { 
  return new Promise((resolve, reject) => {
    userModel.findOne({ userName: userInfo.username }, function(err, userObj) {
      if (err) {
        reject({message: 'Internal server error', status: 500});
      } else {
        if(!userObj) { reject({ message: 'You are not registered user', status: 403 }); }
        else { resolve({ user:userObj, message: 'user found', status: 200 }); }       
      }
    });
  });
};

// Handles to insert new user into the database
const addUser = (userInfo) => {
  return new Promise((resolve, reject) => {
    findUser(userInfo).then(
      (res) => {
        reject({message: 'username is already exist', status: 403});
      },
      (err) => { 
        let newUser = new userModel();
        newUser.userId = uuid();
        newUser.userName = userInfo.username;
        newUser.emailId = userInfo.emailid;
        newUser.password = encrypt(userInfo.password);
        newUser.save((err, userInfo) => {
          if(err) {
            reject({message: 'Internal Server Error', status: 500});
          } else {
            resolve({ userInfo: {userName: userInfo.userName}, message: 'Registered successfully', status:201 });
          }
        });
      });
  });
};

// Verifies user login data 
const verifyUser = (userInfo) => {
  return new Promise((resolve, reject) => {
    findUser(userInfo).then(
      (res) => {
        if (!verifyPassword(userInfo.password, res.user.password)) { 
          reject({message: 'Passwords is incorrect', status: 403}); 
        }
        else {
          auth.signToken({userName:res.user.userName, userId:res.user.userId}, tokenConfig.secretKey, '1h', (tokenErr, tokenRes) => {
            if(tokenErr) {
              reject({message: tokenErr, status: 403});
            }
            else {
              resolve({token: tokenRes, user:{ userName: res.user.userName, userId: res.user.userId}, status: 200 });
            }
          });          
        }
      },
      (err) => {
        if  (err.message === 'You are not registered user')
        { reject({ message: 'You are not registered user', status: 403 }); }
        else { reject(err); }
      });
  })
}

const findUserByEmailID = (emailId) => { 
  return new Promise((resolve, reject) => {
    userModel.findOne({ emailId: emailId }, function(err, userObj) {
      if (err) {
        reject({message: 'Internal server error', status: 500});
      } else {
        if(!userObj) { reject({ message: 'You are not registered user', status: 403 }); }
        else { resolve({ user:userObj, message: 'user found', status: 200 }); }       
      }
    });
  });
};


function encrypt(val) {
  var salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(val, salt);
}

function verifyPassword(val, hash) {
  return bcrypt.compareSync(val, hash);
}

module.exports = {
  addUser,
  verifyUser,
  findUserByEmailID
}
