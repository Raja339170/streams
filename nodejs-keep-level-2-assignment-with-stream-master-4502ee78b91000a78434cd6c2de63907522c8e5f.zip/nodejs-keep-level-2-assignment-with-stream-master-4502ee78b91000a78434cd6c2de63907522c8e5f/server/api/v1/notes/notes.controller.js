const notesService =  require('./notes.services');

// Handler to add a note into a database
const addNote = (userId, note) => {
  return notesService.addNote(userId, note);
}

// Handler to get notes
const getNotes = (userId) => {
  return notesService.getNotes(userId);
}
// Handler to update note
const updateNote = (noteId, editedNote) => {
  return notesService.updateNote(noteId, editedNote);
}

// Handler to insert bulk notes
const insertNotesAsStream = () => {
	return notesService.insertNotesAsStream();  
}

// Handler to get bulk notes
const getNotesAsStream = (res) =>{
	return notesService.getNotesAsStream(res);
}


const shareNotes = (emailId, notes) => {
  return notesService.shareNotes(emailId, notes);
}

module.exports = {
  addNote,
  getNotes,
  updateNote,
  shareNotes,
  insertNotesAsStream,
  getNotesAsStream
}
