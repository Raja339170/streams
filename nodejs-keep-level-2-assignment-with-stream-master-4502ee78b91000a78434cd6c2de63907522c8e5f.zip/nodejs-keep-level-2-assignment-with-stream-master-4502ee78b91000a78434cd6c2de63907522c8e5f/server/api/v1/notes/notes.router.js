const router = require('express').Router();
const notesCtrl = require('./notes.controller');
let auth = require('../auth');
const { tokenConfig } = require('../../../config').appConfig;
const readline = require('readline');
const socketObj = require('../../../socket/socketServer');

// api to insert bulk notes as stream
router.post('/stream', (req, res) => {
  try {
      notesCtrl.insertNotesAsStream().then((response) => {
        console.log('insertNotesAsStream response',response);
        res.status(response.status).send(response.message);
      },
      (err) => {
        console.log('err',err);
        res.status(err.status).send(err);
      });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }

});

// api to get all notes from db
router.get('/stream', (req, res) => {
  notesCtrl.getNotesAsStream(res);
});

// Authentication before handling request
router.use(function(req, res, next) {
  const authorizationHeader = req.get('Authorization');
  if (!authorizationHeader) {
    res.status(403).send('Not authenticated');
  }
  else {
  const token = authorizationHeader.replace('Bearer ', '');
  auth.verifyToken(token, tokenConfig.secretKey, (err, decoded) => {
    if(err) {
        res.status(403).send('invalid token');
      } else {
        next();
    }
  });
}
});

// api to add a note
router.post('/', (req, res, next) => {
  let note = req.body;
  let userId = req.query.userId;
  try {
      notesCtrl.addNote(userId, note).then((response) => {
        res.status(response.status).send(response.note);
      },
      (err) => {
        res.status(err.status).send(err);
      });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to get all notes into database
router.get('/', (req, res, next) => {
  let userId = req.query.userId;
  try {
    notesCtrl.getNotes(userId).then((response) => {
      res.status(response.status).send(response.notes);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to update a note
router.put('/:noteId', (req, res, next) => {
  try {
    let userId = req.query.userId;
    let noteId = req.params.noteId;
    let editedNote =  req.body;
    notesCtrl.updateNote(noteId, editedNote).then((response) => {
      res.status(response.status).send(response.updatedNote);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to share selected notes
router.post('/share', (req, res, next) => {
  let notes = req.body;
  let emailId = req.query.emailId;
  let socket = socketObj.getSocket();

  try {
    notesCtrl.shareNotes(emailId, notes).then((response) => {
      socket.emit(emailId, 'notesShared');
      res.status(response.status).send(response.message);
    },
    (err) => {
      res.status(err.status).send(err.message);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;
