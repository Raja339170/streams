let noteModel = require('./notes.entity');
const uuidv1 = require('uuid/v1');
const streamToMongoDB = require('stream-to-mongo-db').streamToMongoDB;
const fs = require('fs');
const { dbConfig }  = require('../../../config').appConfig;
const path = require('path');
const matchesFile = path.resolve(__dirname, '../../..', 'mydata', 'mock_notes.json');
const JSONStream = require('JSONStream');
const { findUserByEmailID } = require('../user/user.dao')

// Handles to insert newly created note into the database
const addNote = (userId, note) => {
  return new Promise((resolve, reject) => {
    let newNote = new noteModel();
    newNote.id = uuidv1();
    newNote.title = note.title;
    newNote.text = note.text;
    newNote.userId = userId;
    newNote.save((err, note) => {
      if(err) {
        resolve(handleNotesErr(err));
      } else {
        resolve({note: note, message: 'Note is added successfully', status:201});
      }
    });
});
};

// Handles to get all notes from database
const getNotes = (userId) => {
  return new Promise((resolve, reject) => {
    noteModel.find({ userId: userId }, (err, notes) => {
      if (err) {
        resolve(handleNotesErr(err));
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};

// Handles to update a note into the database
const updateNote = (noteId, editedNote) => {
  return new Promise((resolve, reject) => {
    delete editedNote['_id'];
    delete editedNote['userId'];
    delete editedNote['createdOn'];
    delete editedNote['id'];
    editedNote['modifiedOn'] = new Date();
    noteModel.findOneAndUpdate({id: noteId}, editedNote, {new: true}, function(err, note) {
      if (err) {
        resolve(handleNotesErr(err));
      } else {
        resolve({updatedNote: note, message: 'Note is updated successfully', status: 200});
      }
    });
  });
};

// Handles to insert bulk data to DB
const insertNotesAsStream = () => {
  return new Promise((resolve, reject) => {
  const writableStream = streamToMongoDB({ dbURL: dbConfig.mongoUrl, collection: 'notes' });

  const stream = fs.createReadStream(matchesFile)
  stream.pipe(JSONStream.parse('*'))
    .pipe(writableStream);

    stream.on('end', () => {
      resolve({message: 'Notes updated successfully', status: 200})
    });
    
  });
}

// Handles to get bulk data from DB
const getNotesAsStream = (outStream) => {  
  let query = {};
  let fieldOptions = null;
  let page = 1;

  noteModel
    .find(query)
    .select(fieldOptions)
    .lean()
    .cursor()
    .pipe(JSONStream.stringify())
    .pipe(outStream.type('json'))
}

const shareNotes = (emailId, notes) => {
  return new Promise((resolve, reject) => {
    findUserByEmailID(emailId).then(
    (res) => {
      notes.forEach((note, i) => {
        let isError = false;
        addNote(res.user.userId, note).then(
          res => {
            if (i === notes.length-1) {
              if(!isError)
              resolve({message: 'Shared successfully', status: 200});
              else 
              resolve(handleNotesErr(''));
            }
          }, 
          (err) => {
            if (i === notes.length-1) resolve(handleNotesErr(err));
          });
      });        
    },
    (err) => {
      reject({message: 'Please enter valid email ID to share', status:403});
    });
  })
}

const findNoteByNoteID = (note) => {
  noteModel.findOne({ noteId: note.noteId }, function(err, noteObj) {
      if (err) {
        resolve(handleNotesErr(err));
      } else {
        if(!noteObj) { reject({ message: 'Note not found', status: 403 }); }
        else { resolve({ note:noteObj, message: 'Note found', status: 200 }); }       
      }
    });
}

const handleNotesErr = (err) => {
  return { message:'Internal server error', status: 500 };
}

module.exports = {
  addNote,
  getNotes,
  updateNote,
  shareNotes,
  insertNotesAsStream,
  getNotesAsStream
}
