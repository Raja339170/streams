let notesDAO = require('./notes.dao');
const fs = require('fs');
const { Transform } = require('stream');
const JSONStream = require('JSONStream');
const through2 = require('through2');
const logger = require('../../../logger');

// handles to insert newly created note into the database
const addNote = (userId, note) => {
  return notesDAO.addNote(userId, note);
};

// handles to get all notes from database
const getNotes = (userId) => {
  return notesDAO.getNotes(userId);
};

// handles to update a note into the database
const updateNote = (noteId, editedNote) => {
  return notesDAO.updateNote(noteId, editedNote);
};

// handles to insert bulk notes into the database
const insertNotesAsStream = () => {
	return notesDAO.insertNotesAsStream();
}

// handles to get bulk notes from database
const getNotesAsStream = (res) => {
  return notesDAO.getNotesAsStream(res);
}

// handles to share notes to another user
const shareNotes = (emailId, notes) => {  
  return new Promise((resolve, reject) => {
    if(!emailId) {
      reject({message: 'Please enter valid email ID to share', status:403});
    }
    else  if (!notes || (notes && notes.length === undefined)) {
      reject({message: 'Bad Request', status:400});
    }
    else if (notes.length === 0) {
      reject({message: 'Please send notes to share', status:403});
    }
    else {
      notesDAO.shareNotes(emailId, notes).then(
        res => {
          resolve(res);          
        },
        err => {
          reject(err);
        }
      )
    }
  });
}

module.exports = {
  addNote,
  getNotes,
  updateNote,
  shareNotes,
  insertNotesAsStream,
  getNotesAsStream
}
