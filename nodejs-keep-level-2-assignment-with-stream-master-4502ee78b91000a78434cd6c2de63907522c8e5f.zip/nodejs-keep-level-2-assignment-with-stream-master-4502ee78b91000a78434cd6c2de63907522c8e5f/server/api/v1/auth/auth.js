var jwt = require('jsonwebtoken');

function signToken(payload, secret, expireIn, done) {
	jwt.sign(payload, secret, {expiresIn: expireIn}, (err, token) => {
		if (err) { done(err.message); }
		else { done(null, token); }
	});
}

function verifyToken(token, secret, done) {
	jwt.verify(token, secret, (err, decoded) => {
	    if (err) { done(err.message); }
	    else { done(null, decoded); }
	});
}

module.exports = {
  signToken,
  verifyToken
}
