const should = require('chai').should();
const expect = require('chai').expect;
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { signJWTToken, verifyJWTToken } = require('../modules');
let mock_notes = require('../mydata/mock_notes.json');
const { socketConfig } = require('../config').appConfig;

// userID should be same which is used to generate the token
let USER_ID_1;
let USER_ID_2;
let USER_ID_3;

let token_1;
let token_2;
let token_3;

let USER_ID_1_NOTES;

let shareToEmail = 'jaya@gmail.com';

//  testsuite
describe('Testing to add a note', function()
{
  before((done) => {
    request(app)
    .post('/api/v1/users/register')
    .send(config.USER_2)
    .expect(201)
    .end((err, res) => {
      if (err) return done(err);
      shareToEmail = config.USER_2.emailid
      done();
    });
  })
  //  testcase
  it('Should handle a request to add a new note for user 1 ', function(done)
  {
    // Should get added note of user 1 as a respone,  need to match added note text value
    // status = 201
    // response will be added note object
    // Pass valid token in Authorization header as Bearer
    signJWTToken(config.USER_1, config.tokenConfig.secretKey, '1h', (err, token) => {
      token_1 = token;
      request(app)
      .post('/api/v1/notes?userId='+config.USER_1.username)
      .set('Authorization', 'Bearer '+token)
      .send(config.note_1)
      .expect(201)
      .end((err, res) => {
        if (err) return done(err);
        (res.body.text).should.equal(config.note_1.text)
        done();
      });  
   });
	
  });

  //  testcase
  it('Should handle a request to add a new note for user 2', function(done)
  {
    // Should get added note of user 2 as a respone,  need to match added note text value
    // status = 201
    // response will be added note object
    // Pass valid token in Authorization header as Bearer
    signJWTToken(config.USER_2, config.tokenConfig.secretKey, '1h', (err, token) => {
      token_2 = token;
    request(app)
      .post('/api/v1/notes?userId='+config.USER_2.username)
      .set('Authorization', 'Bearer '+token_2)
      .send(config.note_2)
      .expect(201)
      .end((err, res) => {
        if (err) return done(err);
        (res.body.text).should.equal(config.note_2.text)
        done();
      }); 
    })
  });
});

//  testsuite
describe('Testing to get all notes', function()
{
  //  testcase
  it('Should handle a request to get all notes of a user 1', function(done)
  {
    // Should get all note as a array those are created by user 1 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 1
    // Pass valid token in Authorization header as Bearer
    request(app)
      .get('/api/v1/notes?userId='+config.USER_1.username)
      .set('Authorization', 'Bearer '+token_1)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        USER_ID_1_NOTES = res.body;
        (res.body[res.body.length-1].text).should.equal(config.note_1.text)
        done();
      });
  });

  //  testcase
  it('Should handle a request to get all notes of a user 2', function(done)
  {
    // Should get all note as a array those are created by user 2 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 2
    // Pass valid token in Authorization header as Bearer
    request(app)
    .get('/api/v1/notes?userId='+config.USER_2.username)
    .set('Authorization', 'Bearer '+token_2)
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      (res.body[res.body.length-1].text).should.equal(config.note_2.text)
      done();
    });
  });

  //  testcase
  it('Should handle a request to get notes of a user who has not created any note', function(done)
  {
      // should get blank array
      // status = 200
      // response will be an empty array
      // Pass valid token in Authorization header as Bearer
      signJWTToken(config.USER_3, config.tokenConfig.secretKey, '1h', (err, token) => {
        token_3 = token;
      request(app)
      .get('/api/v1/notes?userId='+config.USER_3.username)
      .set('Authorization', 'Bearer '+token_3)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        (res.body.length).should.equal(0)
        done();
      });
    });
  });
});

//  testsuite
describe('Testing to update a note', function()
{
  //  testcase
  it('Should handle a request to update a note by note id', function(done)
  {
    // Should return updated note and match updated note text value'
    // status = 200
    // response will hold updated note as an object
    // Pass valid token in Authorization header as Bearer
    request(app)
    .put('/api/v1/notes/'+USER_ID_1_NOTES[0].id)
    .set('Authorization', 'Bearer '+token_1)
    .send({state:"started"})
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.text).should.equal(USER_ID_1_NOTES[0].text)
      done();
    });
  });
});

describe('Negative test scenarios', function() {
    it('Make a API request to a resource with invalid token, which requires authentication, should return forbidden status and error ', function(done) { 
      let invalidToken = token_1+' ';
      request(app)
      .get('/api/v1/notes?userId='+USER_ID_1)
      .set('Authorization', 'Bearer '+invalidToken)
      .expect(403)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('invalid token');
        done();
      }); 
    });
    it('Make a API request to a resource without any token, which requires authentication, should return forbidden status and error ', function(done) {
      request(app)
      .get('/api/v1/notes?userId='+USER_ID_1)
      .expect(403)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Not authenticated');
        done();
      }); 
    });
});

describe('Testing notes with bulk data', function()
{
  it('Should handle a request to insert bulk data', function(done) { 
    request(app)
      .post('/api/v1/notes/stream')
      .send(mock_notes)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Notes updated successfully');
        done();
      }); 
  });

  it('Should handle a request to get bulk data', function(done) { 
    request(app)
      .get('/api/v1/notes/stream')
      .expect(200)
      .end((err, res) => {
        if (err) return done(err);
        expect(res.body).to.have.lengthOf.above(0);
        done();
      }); 
  });

});

describe('Testing notes by sharing using socket', function()
{
  let socket;
  before((done) => {
    let url = 'http://'+socketConfig.hostname+':'+socketConfig.port;
    socket = require('socket.io-client')(url);
    socket.on('connected', (data) => {
        console.log("connected :: ", data);
        done();
    }); 
  });

  it('Should handle a request to share notes with emailId', function(done) { 
   
    request(app)
      .post('/api/v1/notes/share?emailId='+shareToEmail)
      .set('Authorization', 'Bearer '+token_1)
      .send(mock_notes)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err); 
        (res.text).should.equal('Shared successfully'); 
        done();
      }); 
  });

  it('Should handle a request to share notes with emailId that should send data through socket', function(done) { 
    request(app)
      .post('/api/v1/notes/share?emailId='+shareToEmail)
      .set('Authorization', 'Bearer '+token_1)
      .send(mock_notes)
      .expect(200)
      .expect(200)
      .end((err, res) => {
        if (err) return done(err); 
        (res.text).should.equal('Shared successfully'); 
      });

      socket.on(shareToEmail, data => {
        expect(data).to.have.lengthOf.above(0);
        done();
      });
  });

  it('Should handle a request without email ID', function(done) { 
    request(app)
      .post('/api/v1/notes/share?emailId=')
      .set('Authorization', 'Bearer '+token_1)
      .send([])
      .expect(403)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Please enter valid email ID to share');
        done();
      }); 
  });

  it('Should handle a request to share notes with undefined data', function(done) { 
    request(app)
      .post('/api/v1/notes/share?emailId='+shareToEmail)
      .set('Authorization', 'Bearer '+token_1)
      .send({})
      .expect(400)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Bad Request');
        done();
      }); 
  });

  it('Should handle a request to share notes with empty array', function(done) { 
    request(app)
      .post('/api/v1/notes/share?emailId='+shareToEmail)
      .set('Authorization', 'Bearer '+token_1)
      .send([])
      .expect(403)
      .end((err, res) => {
        if (err) return done(err);
        (res.text).should.equal('Please send notes to share');
        done();
      }); 
  });

});
