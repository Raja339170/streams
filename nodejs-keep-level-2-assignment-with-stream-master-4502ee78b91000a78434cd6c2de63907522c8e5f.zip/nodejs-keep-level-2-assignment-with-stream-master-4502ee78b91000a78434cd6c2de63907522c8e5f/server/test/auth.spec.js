const expect = require('chai').expect;
const assert = require('chai').assert;
const { signJWTToken, verifyJWTToken } = require('../modules');
const config = require('./test.config');

let USER_1_TOKEN;
let USER_2_TOKEN;

const maxExp_1 = "1h";
const maxExp_2 = "1";

describe('JWT Token test scenarios', function() {
    
	before(function(done) { 
		signJWTToken(config.USER_2, config.tokenConfig.secretKey, maxExp_2, (err, token) => {
			USER_2_TOKEN = token;
			done() ;
		});
	});
	
	after(function(done) { done(); });

	it('Assert signing & verification methods exists and are valid', function() {
		expect(signJWTToken).to.not.equal(undefined);
		expect(signJWTToken).to.not.equal(null);
		expect(typeof(signJWTToken)).to.equal('function');
		expect(signJWTToken.length).to.be.above(0, 'this method must have arguments');

		expect(verifyJWTToken).to.not.equal(undefined);
		expect(verifyJWTToken).to.not.equal(null);
		expect(typeof(verifyJWTToken)).to.equal('function');
		expect(verifyJWTToken.length).to.be.above(0, 'this method must have arguments');

		expect(signJWTToken).to.be.an('function');
	});

	it('sign a token with valid payload, signature, secret and expiry time', function(done) { 
		signJWTToken(config.USER_1, config.tokenConfig.secretKey, maxExp_1, (err, token) => {
			USER_1_TOKEN = token;
			expect(token).to.be.a('string');
      		expect(token.split('.')).to.have.length(3);
			done() ;
		});
	});
	
	it('verification of a valid signed token, must return same payload, which was passed', function(done) {
	 	verifyJWTToken(USER_1_TOKEN, config.tokenConfig.secretKey, (err, userObj) => {
			assert.equal(config.USER_1.username, userObj.username);
			done() ;
		});
	});
	
	it('verification a expired token, must return with appropriate error', function(done) {
		verifyJWTToken(USER_2_TOKEN, config.tokenConfig.secretKey, (err, userObj) => {
			assert.equal('jwt expired', err);
			done() ;
		});
	});
	
	it('verification a invalid, must return with appropriate error', function(done) {
		let invalidToken = USER_1_TOKEN+' ';
	 verifyJWTToken(invalidToken, config.tokenConfig.secretKey, (err, userObj) => {
			assert.equal('invalid token', err);
			done() ;
		});
	});

});