const appConfig = require('./appConfig');
module.exports = {
  appConfig
}