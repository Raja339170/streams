## Project Title (Keep Backend Application Level 2)
This is a simple node.js application with MongoDB access, can be used to implementation for CRUD operations with MongoDB

This expects the environment variable MONGO_URL, which you can set using below command 

On Linux platform
```
export MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - $MONGO_URL
```

On Windows platform
```
SET MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - %MONGO_URL%
```


### How to run this project

1. Install dependencies

```
npm install
```

or

```
yarn
```

2. Run node application from terminal

```
npm run serv
```

3. Run test cases from terminal

```
npm run test
```

4. Run lint checks from terminal

```
npm run lint
```


### Sample urls to test login and notes

1.  Register user (POST)

```
http://localhost:3000/api/v1/users/register
```

```
Req Body content
{
    "username":"Jaya",
    "emailid::"jaya@gmail.com",
    "password":"password"
}
```

2. Login user (POST)

```
http://localhost:3000/api/v1/users/login
```

```
Req Body content
{
    "username":"Jaya",
    "password":"password"
}
```

3. Add note (POST) with Authentication

```
http://localhost:3000/api/v1/notes?userId=Jaya
```

```
Req Body content
{
    "title":"Bill",
    "text":"Electicity Bill",
    
}
```

4.  Get All notes

```
http://localhost:3000/api/v1/notes?userId=Jaya
```

5. Update (PUT) with Authentication

```
http://localhost:3000/api/v1/notes/9c2fa030-8986-11e8-b2d5-491a66d70a96
```

```
Req Body content
{
    "title":"Bill",
    "text":"Electicity Bill",
    "status":"started"
}
```

6. Share one or more notes (POST) with Authentication

```
http://localhost:3000/api/v1/notes/share?emailID=jaya@gmail.com
```

```
Req Body content
[{
    "title":"Bill",
    "text":"Electicity Bill",
    "status":"started"
}]
```

7. Push one or more notes into DB (POST)

```
http://localhost:3000/api/v1/notes/stream
```

```
Req Body content
[{
    "title":"Bill",
    "text":"Electicity Bill",
    "status":"started"
}]
```

7. Get one or more notes into DB (GET)

```
http://localhost:3000/api/v1/notes/stream
```


